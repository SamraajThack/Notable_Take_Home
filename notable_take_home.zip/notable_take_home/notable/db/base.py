from notable.models.appointment import Appointment
from notable.models.doctor import Doctor
from notable.db.base_class import Base

